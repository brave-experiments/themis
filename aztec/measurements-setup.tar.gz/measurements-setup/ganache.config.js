module.exports = {
  host: '127.0.0.1',
  port: 8545,
  numberOfAccounts: 10,
  defaultBalanceEther: 10000,
};
