#include "header.h"
#include <iostream>

namespace brave {
namespace themis_client {
	void run_example() {
		std::cout << "Do stuff in CPP\n";
	}
}
}
