#pragma once
#include "rust/cxx.h"

namespace brave {
namespace themis_client {
	void run_example();
}
}
