## THEMIS client

**Run tests**

```
 // Run tests locally:
 $ CONTRACT_ADDR=c2fC3Ecfa5d00B34a6F35977884843B337870e2a cargo test

 // Run tests against remote sidechain
 $ SIDECHAIN_ADDR=http://52.90.98.76:22000 CONTRACT_ADDR=8C9061399FF5e4db1E0570505Ad96f492a1786Ba cargo test
```
